A Pen created at CodePen.io. You can find this one at http://codepen.io/42EG4M1/pen/bVMzze.

 Text blur Animation CSS(SCSS) Only.